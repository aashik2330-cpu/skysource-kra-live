import React, { useMemo, useState } from 'react';
import { getParamsForDesignation, getRating, sortMonths } from '../../services/kraRules';

export default function EmployeeDashboard({ name, dataset, canEdit = false, onEdit }) {
  const [month, setMonth] = useState('all');
  const [tab, setTab] = useState('overview');
  const meta = dataset.meta[name] || {};
  const months = sortMonths(Object.keys(dataset.data[name] || {}));
  const scores = useMemo(() => {
    if (month !== 'all') return dataset.data[name]?.[month] || null;
    if (!months.length) return null;
    const params = getParamsForDesignation(dataset.settings.params, meta.desig);
    const avg = { status: dataset.data[name][months[months.length - 1]]?.status || 'Active' };
    params.forEach(p => avg[p.key] = Math.round(months.reduce((s,m)=>s+Number(dataset.data[name][m][p.key]||0),0)/months.length*100)/100);
    avg.overall = Math.round(months.reduce((s,m)=>s+Number(dataset.data[name][m].overall||0),0)/months.length*100)/100;
    return avg;
  }, [month, name, dataset, meta.desig, months]);
  const rating = getRating(scores?.overall || 0);
  const params = getParamsForDesignation(dataset.settings.params, meta.desig);
  return <div className="page">
    <div className="dashboard-head"><div><h1>{name}</h1><p>{month === 'all' ? 'All Months Average' : month} - SkySource KRA Dashboard</p></div><div className="head-actions"><select value={month} onChange={e=>setMonth(e.target.value)}><option value="all">All Months (Average)</option>{months.map(m=><option key={m}>{m}</option>)}</select>{canEdit && <button onClick={onEdit}>Edit Data</button>}</div></div>
    <div className="tabs"><button className={tab==='overview'?'active':''} onClick={()=>setTab('overview')}>Overview</button><button className={tab==='params'?'active':''} onClick={()=>setTab('params')}>Parameters</button><button className={tab==='trend'?'active':''} onClick={()=>setTab('trend')}>Monthly Trend</button></div>
    {!scores && <div className="filter-card">No data available.</div>}
    {scores && tab==='overview' && <><section className="meta-bar"><Info label="Employee ID" val={meta.id}/><Info label="Designation" val={meta.desig}/><Info label="Supervisor" val={meta.sup}/><Info label="Email" val={meta.email}/><Info label="Status" val={meta.status || scores.status}/></section><section className="score-cards"><Score label="Overall Rating" value={scores.overall} rating={rating}/><Score label="Applicable Parameters" value={params.length}/><Score label="Months Available" value={months.length}/></section></>}
    {scores && tab==='params' && <section className="param-grid">{params.map(p => <ParamCard key={p.key} p={p} v={Number(scores[p.key]||0)} />)}</section>}
    {scores && tab==='trend' && <Trend months={months.slice(-12)} data={dataset.data[name]} />}
  </div>
}
function Info({label,val}) { return <div><span>{label}</span><strong>{val || '-'}</strong></div> }
function Score({label,value,rating}) { return <div className="score-card"><span>{label}</span><strong style={{color: rating?.color}}>{typeof value === 'number' ? value.toFixed ? value.toFixed(2) : value : value}</strong>{rating && <em>{rating.grade} - {rating.label}</em>}</div> }
function ParamCard({p,v}) { const pct = Math.min(100, v/5*100); return <div className="param-card"><div><strong>{p.label}</strong><span>Rating /5</span></div><b>{v.toFixed(2)} <small>/5.00</small></b><i><u style={{width:`${pct}%`,background:p.color}} /></i><em>{Math.round(pct)}% of max</em></div> }
function Trend({months,data}) { return <div className="filter-card"><h3>Monthly Overall Score Trend - Latest 12 Months</h3><div className="trend-bars">{months.map(m => <div key={m}><span>{m}</span><b style={{height:`${(Number(data[m]?.overall||0)/5)*140}px`}} title={Number(data[m]?.overall||0).toFixed(2)} /></div>)}</div></div> }
