import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Layout({ children, page, setPage }) {
  const { profile, signOut, isPrivileged } = useAuth();
  const [open, setOpen] = useState(false);
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand"><div className="brand-mark small">S</div><div><strong>SkySource KRA</strong><span>Performance Dashboard</span></div></div>
        <button className={page === 'home' ? 'nav active' : 'nav'} onClick={() => setPage('home')}>Home</button>
        {isPrivileged && <button className={page === 'reports' ? 'nav active' : 'nav'} onClick={() => setPage('reports')}>Reports</button>}
        {isPrivileged && <button className={page === 'admin' ? 'nav active' : 'nav'} onClick={() => setPage('admin')}>Admin Config</button>}
      </aside>
      <main className="main">
        <header className="topbar">
          <div>Welcome, <strong>{profile?.full_name}</strong></div>
          <div className="profile-menu-wrap">
            <button className="avatar-btn" onClick={() => setOpen(!open)}>{profile?.full_name?.[0] || 'U'}</button>
            {open && <div className="profile-menu"><div className="menu-title">Signed in as<br/><strong>{profile?.full_name}</strong></div><button onClick={signOut}>Logout</button></div>}
          </div>
        </header>
        {children}
      </main>
    </div>
  );
}
