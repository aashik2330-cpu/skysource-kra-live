import React, { useState } from 'react';
import { DEFAULT_ASSOCIATE_PASSWORD } from '../services/kraRules';
import { supabase } from '../lib/supabaseClient';

export default function AdminPanel() {
  const [form, setForm] = useState({ email: '', fullName: '', role: 'associate', password: DEFAULT_ASSOCIATE_PASSWORD });
  const [message, setMessage] = useState('');

  async function createUser(e) {
    e.preventDefault();
    setMessage('Creating user...');
    const { data, error } = await supabase.functions.invoke('admin-create-user', { body: form });
    setMessage(error ? error.message : `User created: ${data?.email || form.email}`);
  }

  return (
    <div className="page">
      <section className="filter-card">
        <h2>Admin Config</h2>
        <p>Create associate/supervisor users. Default associate password is <strong>{DEFAULT_ASSOCIATE_PASSWORD}</strong>.</p>
        <form className="admin-form" onSubmit={createUser}>
          <input placeholder="Full Name" value={form.fullName} onChange={e => setForm({ ...form, fullName: e.target.value })} required />
          <input placeholder="Email" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
          <select value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}><option value="associate">Associate</option><option value="supervisor">Supervisor</option><option value="admin">Admin</option></select>
          <input placeholder="Password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
          <button>Create User</button>
        </form>
        {message && <div className="info-box">{message}</div>}
      </section>
    </div>
  );
}
