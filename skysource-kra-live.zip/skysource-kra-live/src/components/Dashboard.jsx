import React, { useMemo, useState } from 'react';
import { getParamsForDesignation, getRating, initials, sortMonths } from '../services/kraRules';
import { useAuth } from '../context/AuthContext';

export default function Dashboard({ dataset, onSelectEmployee }) {
  const { profile, isPrivileged } = useAuth();
  const [year, setYear] = useState('all');
  const [month, setMonth] = useState('all');
  const employees = useMemo(() => Object.keys(dataset.data || {}).filter(n => !dataset.meta[n]?.isArchived).sort(), [dataset]);
  const visibleEmployees = isPrivileged ? employees : employees.filter(n => dataset.meta[n]?.email?.toLowerCase() === profile?.email?.toLowerCase() || n === profile?.full_name);
  const allMonths = sortMonths(dataset.months || []);
  const years = [...new Set(allMonths.map(m => m.split(' ')[1]))];

  return (
    <div className="page">
      <section className="hero"><h1>{isPrivileged ? 'SkySource KRA Performance Management' : 'My KRA Performance Dashboard'}</h1><p>{isPrivileged ? 'Manage team performance and reports.' : 'Review your read-only KRA performance summary.'}</p></section>
      <section className="filter-card">
        <strong>{isPrivileged ? 'Filters' : 'Review Period'}</strong>
        <div className="filters-row">
          <label>Year<select value={year} onChange={e => setYear(e.target.value)}><option value="all">All Years</option>{years.map(y => <option key={y}>{y}</option>)}</select></label>
          <label>Month<select value={month} onChange={e => setMonth(e.target.value)}><option value="all">All Months</option>{['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'].map(m => <option key={m}>{m}</option>)}</select></label>
        </div>
      </section>
      <section className={isPrivileged ? 'employee-grid' : 'associate-summary-grid'}>
        {visibleEmployees.map(name => <EmployeeCard key={name} name={name} dataset={dataset} year={year} month={month} onClick={() => onSelectEmployee?.(name)} />)}
      </section>
    </div>
  );
}

function EmployeeCard({ name, dataset, year, month, onClick }) {
  const meta = dataset.meta[name] || {};
  const months = sortMonths(Object.keys(dataset.data[name] || {})).filter(m => (year === 'all' || m.endsWith(year)) && (month === 'all' || m.startsWith(month)));
  const avg = months.length ? months.reduce((sum, m) => sum + Number(dataset.data[name][m].overall || 0), 0) / months.length : 0;
  const latest = months[months.length - 1];
  const rating = getRating(avg);
  const params = getParamsForDesignation(dataset.settings.params, meta.desig);
  return (
    <div className="employee-card" onClick={onClick} style={{ borderLeftColor: rating.color }}>
      <div className="card-head"><div className="avatar" style={{ color: rating.color, background: rating.color + '18' }}>{initials(name)}</div><div><h3>{name}</h3><p>{meta.desig}</p><p className="muted">Supervisor: {meta.sup || '-'}</p></div></div>
      <div className="score-line"><strong style={{ color: rating.color }}>{avg ? avg.toFixed(2) : '-'}</strong><span>{rating.grade} - {rating.label}</span></div>
      <div className="muted">Latest: {latest || '-'} | Applicable parameters: {params.length}</div>
    </div>
  );
}
