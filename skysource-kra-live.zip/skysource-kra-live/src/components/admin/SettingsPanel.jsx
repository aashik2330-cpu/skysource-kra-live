import React, { useState } from 'react';
import { saveSettings } from '../../services/kraService';

export default function SettingsPanel({ dataset, reload }) {
  const [settings, setSettings] = useState(dataset.settings);
  async function save() { await saveSettings(settings); reload?.(); }
  return <section className="filter-card"><h2>Settings</h2><p>Manage parameter labels and colors. Weight editor can be extended here.</p>{settings.params.map((p,i)=><div className="settings-row" key={p.key}><input value={p.label} onChange={e=>{const params=[...settings.params]; params[i]={...p,label:e.target.value}; setSettings({...settings,params});}}/><input type="color" value={p.color} onChange={e=>{const params=[...settings.params]; params[i]={...p,color:e.target.value}; setSettings({...settings,params});}}/></div>)}<button onClick={save}>Save Settings</button></section>
}
