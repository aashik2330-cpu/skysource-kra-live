import React, { useState } from 'react';
import AdminUsers from './AdminUsers';
import BulkUpload from './BulkUpload';
import SettingsPanel from './SettingsPanel';

export default function AdminPanel({ dataset, reload }) {
  const [tab, setTab] = useState('users');
  return <div className="page"><div className="tabs"><button className={tab==='users'?'active':''} onClick={()=>setTab('users')}>Users & Passwords</button><button className={tab==='upload'?'active':''} onClick={()=>setTab('upload')}>Bulk Upload</button><button className={tab==='settings'?'active':''} onClick={()=>setTab('settings')}>Settings</button></div>{tab==='users' && <AdminUsers reload={reload}/>} {tab==='upload' && <BulkUpload dataset={dataset} reload={reload}/>} {tab==='settings' && <SettingsPanel dataset={dataset} reload={reload}/>}</div>
}
