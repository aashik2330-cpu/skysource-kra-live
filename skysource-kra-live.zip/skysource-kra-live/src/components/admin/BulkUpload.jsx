import React, { useState } from 'react';
import { parseKraWorkbook } from '../../utils/excel';
import { upsertEmployee, upsertKraRecord } from '../../services/kraService';

export default function BulkUpload({ dataset, reload }) {
  const [msg, setMsg] = useState('');
  async function handleFile(file) {
    const buf = await file.arrayBuffer();
    const parsed = parseKraWorkbook(buf, dataset.settings);
    setMsg(`Parsed ${parsed.employees.length} employees and ${parsed.records.length} records. Saving...`);
    const employeeMap = new Map();
    for (const e of parsed.employees) { const saved = await upsertEmployee(e); employeeMap.set(e.full_name, saved.id); }
    for (const r of parsed.records) { const employee_id = employeeMap.get(r.full_name); const { full_name, ...rec } = r; await upsertKraRecord({ ...rec, employee_id }); }
    setMsg('Upload complete.'); reload?.();
  }
  return <section className="filter-card"><h2>Bulk Upload Excel</h2><p>Upload the professional Summary workbook.</p><input type="file" accept=".xlsx,.xlsm" onChange={e=>e.target.files?.[0] && handleFile(e.target.files[0])}/>{msg && <div className="info-box">{msg}</div>}</section>
}
