import React, { useState } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { DEFAULT_ASSOCIATE_PASSWORD } from '../../services/kraRules';

export default function AdminUsers({ reload }) {
  const [form, setForm] = useState({ email: '', fullName: '', role: 'associate', password: DEFAULT_ASSOCIATE_PASSWORD });
  const [msg, setMsg] = useState('');
  async function submit(e) { e.preventDefault(); const { data, error } = await supabase.functions.invoke('admin-create-user', { body: form }); setMsg(error ? error.message : `Created ${data.email}`); reload?.(); }
  return <section className="filter-card"><h2>Create / Reset User Access</h2><p>Default associate password: <strong>{DEFAULT_ASSOCIATE_PASSWORD}</strong></p><form className="admin-form" onSubmit={submit}><input required placeholder="Full name" value={form.fullName} onChange={e=>setForm({...form,fullName:e.target.value})}/><input required type="email" placeholder="Email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/><select value={form.role} onChange={e=>setForm({...form,role:e.target.value})}><option value="associate">Associate</option><option value="supervisor">Supervisor</option><option value="admin">Admin</option></select><input placeholder="Password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/><button>Create User</button></form>{msg && <div className="info-box">{msg}</div>}</section>
}
