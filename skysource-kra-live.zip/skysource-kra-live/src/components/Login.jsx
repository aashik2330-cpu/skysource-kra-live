import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { signIn } = useAuth();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await signIn(form.email.trim().toLowerCase(), form.password);
    } catch (err) {
      setError(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page">
      <div className="login-card">
        <section className="login-form-panel">
          <div className="brand-row">
            <div className="brand-mark">S</div>
            <div>
              <div className="brand-title">SkySource KRA</div>
              <div className="brand-subtitle">Performance Management</div>
            </div>
          </div>
          <h1>Sign in to your dashboard</h1>
          <p className="login-intro">Access monthly KRA ratings, performance trends, reviews, and management reports.</p>
          <form onSubmit={handleSubmit}>
            <label>Work Email</label>
            <input type="email" autoComplete="username" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
            <label>Password</label>
            <input type="password" autoComplete="current-password" required value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
            {error && <div className="error-box">{error}</div>}
            <button disabled={loading}>{loading ? 'Signing in...' : 'Sign In'}</button>
          </form>
          <div className="login-footer-note">Internal Use Only</div>
        </section>
        <section className="login-visual-panel">
          <div className="visual-content">
            <div className="eyebrow">Performance Intelligence</div>
            <h2>Data-driven KRA reviews for modern operations teams.</h2>
            <p>Secure role-based access for admins, supervisors, and associates.</p>
            <div className="mock-window">
              <div className="mock-top"><span/><span/><span/></div>
              <div className="mock-chart"><i/><i/><i/><b/></div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
