import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';

export default function ChangePasswordModal({ onClose }) {
  const { changePassword } = useAuth();
  const [form, setForm] = useState({ next: '', confirm: '' });
  const [msg, setMsg] = useState('');
  async function save() {
    if (form.next.length < 8) return setMsg('Password must be at least 8 characters.');
    if (form.next !== form.confirm) return setMsg('Passwords do not match.');
    await changePassword(form.next);
    setMsg('Password changed successfully.');
    setTimeout(onClose, 800);
  }
  return <div className="modal-backdrop"><div className="modal"><h2>Change Password</h2><p>Enter your new password.</p><input type="password" placeholder="New password" value={form.next} onChange={e=>setForm({...form,next:e.target.value})}/><input type="password" placeholder="Confirm password" value={form.confirm} onChange={e=>setForm({...form,confirm:e.target.value})}/>{msg && <div className="info-box">{msg}</div>}<div className="modal-actions"><button className="secondary" onClick={onClose}>Cancel</button><button onClick={save}>Save Password</button></div></div></div>
}
