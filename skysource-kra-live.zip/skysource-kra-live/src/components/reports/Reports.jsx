import React, { useMemo, useState } from 'react';
import { exportRowsToXlsx } from '../../utils/excel';
import { getRating, sortMonths } from '../../services/kraRules';

export default function Reports({ dataset }) {
  const [year, setYear] = useState('all');
  const [status, setStatus] = useState('Active');
  const months = sortMonths(dataset.months || []);
  const years = [...new Set(months.map(m => m.split(' ')[1]))];
  const rows = useMemo(() => {
    const out = [];
    Object.keys(dataset.data || {}).forEach(name => {
      const meta = dataset.meta[name] || {};
      if (status !== 'all' && (meta.isArchived ? 'Archived' : 'Active') !== status) return;
      months.filter(m => year === 'all' || m.endsWith(year)).forEach(m => {
        const rec = dataset.data[name]?.[m];
        if (!rec) return;
        out.push({ 'Emp ID': meta.id, Name: name, Email: meta.email, Designation: meta.desig, Supervisor: meta.sup, Month: m, 'Overall Score': Number(rec.overall||0).toFixed(2), Grade: getRating(rec.overall).grade });
      });
    });
    return out;
  }, [dataset, year, status, months]);
  return <div className="page"><section className="filter-card"><h2>Generate Reports</h2><div className="filters-row"><label>Year<select value={year} onChange={e=>setYear(e.target.value)}><option value="all">All Years</option>{years.map(y=><option key={y}>{y}</option>)}</select></label><label>Status<select value={status} onChange={e=>setStatus(e.target.value)}><option>Active</option><option>Archived</option><option value="all">All</option></select></label><button onClick={()=>exportRowsToXlsx(rows)}>Export Excel</button></div><p>{rows.length} rows found</p></section><section className="filter-card"><table><thead><tr>{Object.keys(rows[0]||{Name:'',Month:'','Overall Score':'',Grade:''}).map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{rows.slice(0,50).map((r,i)=><tr key={i}>{Object.values(r).map((v,j)=><td key={j}>{v}</td>)}</tr>)}</tbody></table></section></div>
}
