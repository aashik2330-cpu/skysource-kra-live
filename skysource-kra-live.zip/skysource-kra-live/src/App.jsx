import React, { useEffect, useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './components/Login';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import AdminPanel from './components/admin/AdminPanel';
import Reports from './components/reports/Reports';
import EmployeeDashboard from './components/dashboard/EmployeeDashboard';
import { getDashboardDataset } from './services/kraService';
import { DEFAULT_SETTINGS } from './services/kraRules';
import './styles.css';

function AppInner() {
  const { loading, session, isPrivileged } = useAuth();
  const [page, setPage] = useState('home');
  const [dataset, setDataset] = useState({ data: {}, meta: {}, months: [], supMap: {}, settings: DEFAULT_SETTINGS });
  const [activeEmployee, setActiveEmployee] = useState(null);
  const [dataLoading, setDataLoading] = useState(true);
  const [error, setError] = useState('');

  const reload = () => {
    setDataLoading(true);
    return getDashboardDataset()
      .then(ds => { setDataset(ds); return ds; })
      .catch(err => setError(err.message || 'Could not load dashboard data'))
      .finally(() => setDataLoading(false));
  };

  useEffect(() => {
    if (!session) return;
    reload();
  }, [session]);

  if (loading) return <div className="loading">Loading...</div>;
  if (!session) return <Login />;

  return (
    <Layout page={page} setPage={setPage}>
      {dataLoading && <div className="loading">Loading dashboard...</div>}
      {error && <div className="error-box">{error}</div>}
      {!dataLoading && page === 'home' && !activeEmployee && <Dashboard dataset={dataset} onSelectEmployee={setActiveEmployee} />}
      {!dataLoading && activeEmployee && <EmployeeDashboard name={activeEmployee} dataset={dataset} canEdit={isPrivileged} onEdit={() => setPage('admin')} />}
      {!dataLoading && page === 'admin' && isPrivileged && <AdminPanel dataset={dataset} reload={reload} />}
      {!dataLoading && page === 'reports' && isPrivileged && <Reports dataset={dataset} />}
    </Layout>
  );
}

export default function App() {
  return <AuthProvider><AppInner /></AuthProvider>;
}
