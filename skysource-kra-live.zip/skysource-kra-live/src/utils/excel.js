import * as XLSX from 'xlsx';
import { calculateOverallFromScores } from '../services/kraRules';

export function safeNum(v) {
  if (v === null || v === undefined || v === '') return 0;
  const n = parseFloat(v);
  return Number.isFinite(n) ? Math.round(n * 10000) / 10000 : 0;
}

export function parseKraWorkbook(arrayBuffer, settings) {
  const wb = XLSX.read(arrayBuffer, { type: 'array' });
  if (!wb.SheetNames.includes('Summary')) throw new Error('Could not find a Summary sheet.');
  const ws = wb.Sheets.Summary;
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: true });
  const employees = new Map();
  const records = [];

  for (let i = 4; i < rows.length; i++) {
    const row = rows[i];
    if (!row) continue;
    const full_name = row[7] ? String(row[7]).trim() : '';
    const monthFull = row[3];
    const year = parseInt(row[2]);
    if (!full_name || !monthFull || !year) continue;
    const month_key = `${String(monthFull).slice(0, 3)} ${year}`;
    const designation = row[8] ? String(row[8]) : '';
    const scores = {
      prod: safeNum(row[12]), qual: safeNum(row[15]), cross: safeNum(row[18]), proc_imp: safeNum(row[21]),
      pkt: safeNum(row[24]), leaves: safeNum(row[27]), escal: safeNum(row[30]), apprec: safeNum(row[33]),
      decorum: safeNum(row[35]), sched: safeNum(row[37]), security: safeNum(row[39]), wfo: safeNum(row[43]),
      leadership: safeNum(row[46]), comm: safeNum(row[49]),
      raw_prod: safeNum(row[11]), raw_qual: safeNum(row[14]), raw_cross: safeNum(row[17]), raw_ideas_sub: safeNum(row[20]),
      raw_pkt: safeNum(row[23]), raw_leaves: safeNum(row[26]), raw_escal: safeNum(row[29]), raw_apprec: safeNum(row[32]),
      raw_warnings: safeNum(row[34]), raw_adherence: safeNum(row[36]), raw_security: safeNum(row[38]),
      status: row[9] ? String(row[9]) : 'Active'
    };
    scores.overall = calculateOverallFromScores(scores, designation, settings);
    employees.set(full_name, {
      employee_code: row[6] ? String(row[6]) : null,
      full_name,
      email: null,
      department: row[5] ? String(row[5]) : '',
      designation,
      supervisor_name: row[10] ? String(row[10]) : '',
      status: row[9] ? String(row[9]) : 'Active'
    });
    records.push({ full_name, month_key, ...scores });
  }
  return { employees: [...employees.values()], records };
}

export function exportRowsToXlsx(rows, fileName = 'SkySource_Report.xlsx') {
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Report');
  XLSX.writeFile(wb, fileName);
}
