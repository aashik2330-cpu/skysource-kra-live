import { supabase } from '../lib/supabaseClient';
import { DEFAULT_SETTINGS, sortMonths } from './kraRules';

export async function getSettings() {
  const { data, error } = await supabase.from('kra_settings').select('settings').eq('id', 'default').maybeSingle();
  if (error) throw error;
  return data?.settings || DEFAULT_SETTINGS;
}

export async function saveSettings(settings) {
  const { error } = await supabase.from('kra_settings').upsert({ id: 'default', settings, updated_at: new Date().toISOString() });
  if (error) throw error;
}

export async function getEmployees() {
  const { data, error } = await supabase.from('employees').select('*').order('full_name');
  if (error) throw error;
  return data || [];
}

export async function getKraRecords() {
  const { data, error } = await supabase
    .from('kra_records')
    .select('*, employee:employees(*)')
    .order('month_key');
  if (error) throw error;
  return data || [];
}

export async function getDashboardDataset() {
  const [employees, records, settings] = await Promise.all([getEmployees(), getKraRecords(), getSettings()]);
  const data = {};
  const meta = {};
  const months = new Set();
  employees.forEach(e => {
    meta[e.full_name] = {
      id: e.employee_code,
      email: e.email,
      dept: e.department,
      desig: e.designation,
      sup: e.supervisor_name,
      doj: e.doj,
      status: e.status,
      isArchived: e.is_archived,
    };
    data[e.full_name] = data[e.full_name] || {};
  });
  records.forEach(r => {
    const name = r.employee?.full_name;
    if (!name) return;
    months.add(r.month_key);
    data[name] = data[name] || {};
    data[name][r.month_key] = r;
  });
  const supMap = {};
  Object.entries(meta).forEach(([name, m]) => {
    const sup = m.sup || 'Unassigned';
    supMap[sup] = supMap[sup] || [];
    supMap[sup].push(name);
  });
  return { data, meta, months: sortMonths([...months]), supMap, settings };
}

export async function upsertEmployee(employee) {
  const { data, error } = await supabase.from('employees').upsert(employee, { onConflict: 'email' }).select().single();
  if (error) throw error;
  return data;
}

export async function upsertKraRecord(record) {
  const { data, error } = await supabase.from('kra_records').upsert(record, { onConflict: 'employee_id,month_key' }).select().single();
  if (error) throw error;
  return data;
}

export async function archiveEmployee(employeeId, isArchived = true) {
  const { error } = await supabase.from('employees').update({ is_archived: isArchived }).eq('id', employeeId);
  if (error) throw error;
}
