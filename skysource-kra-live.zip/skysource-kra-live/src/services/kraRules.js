export const DEFAULT_ASSOCIATE_PASSWORD = 'Skysource@123';

export const DEFAULT_SETTINGS = {
  params: [
    { key: 'prod', label: 'Production', color: '#0f62fe' },
    { key: 'qual', label: 'Quality', color: '#198038' },
    { key: 'cross', label: 'Cross Skilling', color: '#1192e8' },
    { key: 'proc_imp', label: 'Process Improvement', color: '#8a3ffc' },
    { key: 'pkt', label: 'PKT', color: '#d02670' },
    { key: 'leaves', label: 'Unsch. Leaves', color: '#8a5b00' },
    { key: 'escal', label: 'Escalation', color: '#da1e28' },
    { key: 'apprec', label: 'Appreciation', color: '#198038' },
    { key: 'decorum', label: 'Floor Decorum', color: '#da1e28' },
    { key: 'sched', label: 'Sched. Adherence', color: '#0f62fe' },
    { key: 'security', label: 'Security Incident', color: '#da1e28' },
    { key: 'wfo', label: 'WFO%', color: '#1192e8' },
    { key: 'leadership', label: 'Leadership', color: '#8a3ffc' },
    { key: 'comm', label: 'Communication', color: '#0f62fe' },
  ],
  weightsSPA: {
    prod: 0.18, qual: 0.18, cross: 0.06, proc_imp: 0.08, pkt: 0.07, leaves: 0.05,
    escal: 0.05, apprec: 0.05, decorum: 0.08, sched: 0.05, security: 0.05,
    wfo: 0.03, leadership: 0.08, comm: 0.07,
  },
  weightsAgent: {
    prod: 0.22, qual: 0.22, cross: 0.08, proc_imp: 0.08, pkt: 0.10, leaves: 0.05,
    escal: 0.05, apprec: 0.05, decorum: 0.08, sched: 0.05, security: 0.05, wfo: 0.04,
    leadership: 0, comm: 0,
  },
};

export const MONTH_NUMS = { Jan:1, Feb:2, Mar:3, Apr:4, May:5, Jun:6, Jul:7, Aug:8, Sep:9, Oct:10, Nov:11, Dec:12 };

export function sortMonths(arr = []) {
  return [...arr].sort((a, b) => {
    const [am, ay] = String(a).split(' ');
    const [bm, by] = String(b).split(' ');
    return Number(ay) !== Number(by) ? Number(ay) - Number(by) : (MONTH_NUMS[am] || 0) - (MONTH_NUMS[bm] || 0);
  });
}

export function getRating(score) {
  const s = Number(score) || 0;
  if (s >= 4.5) return { grade: 'A+', label: 'Outstanding', color: '#198038' };
  if (s >= 4.0) return { grade: 'A', label: 'Excellent', color: '#198038' };
  if (s >= 3.5) return { grade: 'B', label: 'Good', color: '#0f62fe' };
  if (s >= 3.0) return { grade: 'C', label: 'Average', color: '#8a5b00' };
  return { grade: 'D', label: 'Below Avg', color: '#da1e28' };
}

export function initials(name = '') {
  return String(name).split(' ').filter(Boolean).map(x => x[0]).join('').slice(0, 2).toUpperCase();
}

export function normalizePersonName(name = '') {
  return String(name).split('(')[0].trim().toLowerCase();
}

export const SENIOR_ONLY_PARAM_KEYS = ['leadership', 'comm'];

export function shouldIncludeLeadershipCommunication(designation = '') {
  const d = String(designation).toLowerCase().replace(/\s+/g, ' ').trim();
  const isJuniorOrRegularAssociate = /(^|\s)jr\.?\s/.test(d) ||
    d === 'process analyst' || d === 'quality analyst' || d === 'quality check analyst' ||
    (d.includes('associate') && !d.includes('sr') && !d.includes('senior'));
  if (isJuniorOrRegularAssociate) return false;
  return /(^|\s)sr\.?\s/.test(d) || d.includes('senior') || d.includes('lead') || d.includes('manager') || d.includes('head') || d.includes('spa');
}

export function getParamsForDesignation(params = DEFAULT_SETTINGS.params, designation = '') {
  if (shouldIncludeLeadershipCommunication(designation)) return params;
  return params.filter(p => !SENIOR_ONLY_PARAM_KEYS.includes(p.key));
}

export function calculateOverallFromScores(scores, designation, settings = DEFAULT_SETTINGS) {
  const isSPA = String(designation || '').toLowerCase().includes('spa') || String(designation || '').toLowerCase().includes('leader');
  const weights = isSPA ? settings.weightsSPA : settings.weightsAgent;
  const allowed = new Set(getParamsForDesignation(settings.params, designation).map(p => p.key));
  let total = 0;
  let weightTotal = 0;
  Object.entries(weights || {}).forEach(([key, weight]) => {
    if (allowed.has(key) && scores[key] !== undefined) {
      total += (Number(scores[key]) || 0) * (Number(weight) || 0);
      weightTotal += Number(weight) || 0;
    }
  });
  return weightTotal ? Math.round((total / weightTotal) * 100) / 100 : 0;
}
