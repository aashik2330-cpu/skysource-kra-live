# Migrating Existing HTML Data

The current offline HTML stores seed data in JavaScript constants. For production, migrate data into Supabase tables:

1. `employees`
2. `kra_records`
3. `kra_settings`
4. `profiles` / Supabase Auth users

Recommended practical migration:

- Export the current dashboard data to Excel from Reports.
- Upload the Excel using the new Bulk Upload module.
- Create users through Admin Config or Supabase Auth.

For fully automated migration, extract `SEED_COMPACT` and `ROSTER_UPDATES` from the offline HTML and insert rows using Supabase service-role API.
