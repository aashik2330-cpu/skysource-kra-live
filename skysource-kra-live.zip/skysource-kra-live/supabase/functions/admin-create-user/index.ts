import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

serve(async (req) => {
  try {
    const authHeader = req.headers.get('Authorization') || '';
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceRole = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const admin = createClient(supabaseUrl, serviceRole);
    const userClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: authHeader } } });
    const { data: current } = await userClient.from('profiles').select('role').single();
    if (!current || !['admin', 'supervisor'].includes(current.role)) return new Response('Unauthorized', { status: 403 });
    const { email, password, fullName, role = 'associate' } = await req.json();
    const { data, error } = await admin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { full_name: fullName } });
    if (error) throw error;
    await admin.from('profiles').upsert({ id: data.user.id, email, full_name: fullName, role });
    return Response.json({ id: data.user.id, email });
  } catch (err) {
    return new Response(err.message || 'Failed', { status: 400 });
  }
});
